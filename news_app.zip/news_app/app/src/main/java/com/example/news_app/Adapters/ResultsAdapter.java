package com.example.news_app.Adapters;

import android.content.Context;
import android.icu.text.DateFormat;
import android.os.Build;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.news_app.Models.Fields;
import com.example.news_app.Models.Result;
import com.example.news_app.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ResultsAdapter extends RecyclerView.Adapter<ResultsAdapter.ResultsViewHolder> {

    private final List<Result> resultList;
    private final String mResource;
    private final Context mContext;
    private View.OnClickListener mListener;

    public void msetOnItemClickLister (View.OnClickListener listener){
        mListener = listener;
    }

    public ResultsAdapter(@NonNull Context context, String resource, @NonNull List<Result> results) {
        super();
        mContext = context;
        mResource = resource;
        resultList = results;
    }

    public class ResultsViewHolder extends RecyclerView.ViewHolder {
        private TextView Type;
        private TextView SectionName;
        private TextView PillName;
        private TextView Time;
        private TextView Date;
        private ImageView Thumbnail;
        private TextView Headline;
        private Fields fields;
        private TextView Summary;
        private ImageView State;

        public ResultsViewHolder(@NonNull View itemView) {
            super(itemView);

            View Results = itemView;

            Type = Results.findViewById(R.id.art_type);
            SectionName = Results.findViewById(R.id.art_section);
            PillName = Results.findViewById(R.id.art_pillname);
            Time = Results.findViewById(R.id.art_time);
            Date = Results.findViewById(R.id.art_date);
            Thumbnail = Results.findViewById(R.id.imgThumbnail);
            Headline = Results.findViewById(R.id.art_headline);
            Summary = Results.findViewById(R.id.art_summary);
            State = Results.findViewById(R.id.art_stat);
        }
    }


    @NonNull
    @Override
    public ResultsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.article_card_view, parent, false);
        return new ResultsViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ResultsViewHolder holder, int position) {
            holder.Type.setText(resultList.get(position).getType());
            holder.SectionName.setText(resultList.get(position).getSectionName());
            holder.PillName.setText(resultList.get(position).getPillarName());
            switch(resultList.get(position).getIsHosted().toString()){
                case "true": holder.State.setImageDrawable(mContext.getResources().getDrawable(R.drawable.one_state));break;
                case "false": holder.State.setImageDrawable(mContext.getResources().getDrawable(R.drawable.three_state));break;
            }
            holder.Headline.setText(resultList.get(position).getWebTitle());
            holder.Summary.setText(Html.fromHtml(resultList.get(position).getFields().getBody().substring(0,100).concat("... ")));
            holder.Time.setText(FormatTime(resultList.get(position).getWebPublicationDate()));
            holder.Date.setText(FormatDate(resultList.get(position).getWebPublicationDate()));
            Glide.with(mContext).load(resultList.get(position).getFields().getThumbnail()).into(holder.Thumbnail);
    }

    @Override
    public int getItemCount() {
        return resultList.size();
    }

    public String FormatTime(String Date){
       return Date;//String.valueOf(new SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date));
    }

    public String FormatDate(String Date){
       return Date;//String.valueOf(new SimpleDateFormat("HH:mm:ss aa", Locale.getDefault()).format(Date));
    }


}

