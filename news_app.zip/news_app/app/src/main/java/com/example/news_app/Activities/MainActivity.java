package com.example.news_app.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.news_app.Adapters.ResultsAdapter;
import com.example.news_app.Models.Articles;
import com.example.news_app.Networks.ArticlesUtils;
import com.example.news_app.R;

import java.util.List;

import uk.co.markormesher.android_fab.FloatingActionButton;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<Articles>>{

    // Create a var to store Articles
    private String param_Person;
    private String param_Topic;
    private String param_Location;
    private String BASE_NEWS_URL = "https://content.guardianapis.com/search?";
    private String param_api = "6a469cc7-fb5d-4611-a343-9eaba1eea651";

    private RecyclerView Pages;
    private TextView totalpageSize;
    private TextView currentPage;
    private TextView searchVal;
    private FloatingActionButton Paginate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* *
         * A  Summary of the Guardians API there's a few nifty methods
         * I will use. It has five end points namely:
         *
         * We provide several endpoints to retrieve different items:
         *
         * Content
         * Tags
         * Sections
         * Editions
         * Single item
         *
         * -- Content (q)
         * The content endpoint (/search) returns all pieces of content in the API.
         *
         * - Query operators
         * The q parameter supports AND, OR and NOT operators.
         *
         * --- Filters operators
         * Some filters support AND, OR and NOT operators through a a specific syntax:
         *
         * AND: ,
         * OR: |
         * NOT: -
         * Expressions can be grouped using ().
         *
         * --- Phrase search
         * You can also use double quotes to search for exact phrases.
         *
         * -- Tags
         * The tags endpoint (/tags) returns all tags in the API.
         * All Guardian content is manually categorised using these tags,
         * of which there are more than 50,000.
         *
         * -- Editions
         * Editions are the different front main pages of the Guardian site we have.
         * At current we have editions for the United Kingdom, the United States and Australia.
         *
         * -- Sections
         * The sections endpoint(/sections) returns all sections in the API.
         * We use sections to logically group our content.
         *
         * -- Single item
         * The single item endpoint returns all the data we have for a given single item id.
         *
         * */
        getSupportLoaderManager().initLoader(0,null,this).forceLoad();
        totalpageSize = findViewById(R.id.art_total_pages);
        currentPage = findViewById(R.id.art_current_pages);
        searchVal = findViewById(R.id.art_search_topics);
        Pages = findViewById(R.id.news);

        Paginate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //show me a list four items in the drop down
            }
        });
    }

    @NonNull
    @Override
    public Loader<List<Articles>> onCreateLoader(int id, @Nullable Bundle args) {
        Uri newUri = Uri.parse(BASE_NEWS_URL);

        Uri.Builder uri = newUri.buildUpon();

        uri.appendQueryParameter("api-key",getString(R.string.api_key));
        uri.appendQueryParameter("page","1");//pull from ui
//        for now
        uri.appendQueryParameter("q","celebrities OR politics");//pull from ui
        uri.appendQueryParameter("show-fields","headline,thumbnail,body,publication,byline"); //pull from ui
//        uri.appendQueryParameter("q",param_Person);

        return new ArticlesUtils(this,uri.toString());
    }

    @Override
    public void onLoadFinished(@NonNull Loader<List<Articles>> loader, List<Articles> data) {
        /* *
        *  Instantiate the News Adapter.
        * */
        ResultsAdapter ArticleResults = new ResultsAdapter(this,
                data.get(0).getStatus(),
                data.get(0).getResults());
        LinearLayoutManager llm = new LinearLayoutManager(getApplicationContext());
        // RecyclerView for Articles
        Pages.setLayoutManager(llm);

        Pages.setAdapter(ArticleResults);

        currentPage.setText(data.get(0).getCurrentPage().toString());
        String PagesComparrison = data.get(0).getCurrentPage().toString() + "/" + data.get(0).getPageSize().toString();
        totalpageSize.setText(PagesComparrison);
        //searchVal.setText("hi");
    }

    @Override
    public void onLoaderReset(@NonNull Loader<List<Articles>> loader) {
    }

    @Override
    public void openOptionsMenu() {
//        getMenuInflater().inflate(R.menu.main_menu,);
        super.openOptionsMenu();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        switch(item.getItemId()){
//            case R.menu.main_menu: break;
//            case R.id.action_settings: break;
//        }
        return super.onOptionsItemSelected(item);
    }
}
